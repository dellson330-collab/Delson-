# Atalhos (APK)

App Android com uma grade de atalhos para **sites (links)** e **apps instalados**.

- Toque: abre o site ou o app
- Toque longo: remove o atalho
- Botão "+ Adicionar atalho": novo site (nome + endereço) ou app da lista de instalados
- Os atalhos ficam salvos no aparelho

## Gerar o APK sem instalar nada (GitHub)

1. Crie um repositório no GitHub e envie todo o conteúdo desta pasta (inclusive `.github`).
2. Abra a aba **Actions**, escolha **Gerar APK** e clique em **Run workflow**
   (também roda sozinho a cada push).
3. Quando terminar, abra a execução e baixe o artefato **atalhos-apk**
   (um zip com `app-debug.apk`).
4. Instale no celular (permita "instalar apps de fontes desconhecidas" para o navegador/arquivos).

## Gerar o APK no computador

Com Android Studio: abra a pasta, depois **Build > Build APK(s)**.

Pelo terminal (JDK 17 + Android SDK + Gradle 8.7):

    gradle assembleDebug

O arquivo sai em `app/build/outputs/apk/debug/app-debug.apk`.

## Personalizar

- Atalhos iniciais: método `padrao()` em `app/src/main/java/com/atalhos/app/MainActivity.java`
- Nome do app: `android:label` em `AndroidManifest.xml`
- ID do pacote: `applicationId` em `app/build.gradle`
