package com.atalhos.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Tela única com uma grade de atalhos. Cada atalho é um site (link) ou um app instalado.
 * Toque abre; toque longo remove. Os atalhos ficam salvos no aparelho.
 */
public class MainActivity extends Activity {

    private static final String PREFS = "atalhos";
    private static final String KEY = "itens";
    private static final int COLUNAS = 3;
    private static final int[] CORES = {
            0xFF2563EB, 0xFF16A34A, 0xFFDC2626, 0xFF9333EA, 0xFFEA580C, 0xFF0891B2, 0xFFDB2777
    };

    private GridLayout grade;
    private JSONArray itens;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        carregar();

        LinearLayout raiz = new LinearLayout(this);
        raiz.setOrientation(LinearLayout.VERTICAL);
        raiz.setBackgroundColor(0xFFF4F5F7);

        TextView titulo = new TextView(this);
        titulo.setText("Meus atalhos");
        titulo.setTextSize(TypedValue.COMPLEX_UNIT_SP, 24);
        titulo.setTypeface(Typeface.DEFAULT_BOLD);
        titulo.setTextColor(0xFF111827);
        titulo.setPadding(dp(20), dp(32), dp(20), dp(8));
        raiz.addView(titulo);

        ScrollView rolagem = new ScrollView(this);
        grade = new GridLayout(this);
        grade.setColumnCount(COLUNAS);
        grade.setPadding(dp(8), dp(8), dp(8), dp(8));
        rolagem.addView(grade, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        raiz.addView(rolagem, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        Button adicionar = new Button(this);
        adicionar.setText("+ Adicionar atalho");
        adicionar.setAllCaps(false);
        adicionar.setOnClickListener(v -> escolherTipo());
        LinearLayout.LayoutParams lpBotao = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lpBotao.setMargins(dp(16), dp(8), dp(16), dp(16));
        raiz.addView(adicionar, lpBotao);

        setContentView(raiz);
        atualizar();
    }

    // ---------- dados ----------

    private void carregar() {
        SharedPreferences sp = getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String json = sp.getString(KEY, null);
        try {
            itens = json == null ? padrao() : new JSONArray(json);
        } catch (JSONException e) {
            itens = padrao();
        }
    }

    private void salvar() {
        getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit().putString(KEY, itens.toString()).apply();
    }

    private JSONArray padrao() {
        JSONArray a = new JSONArray();
        a.put(novo("link", "Google", "https://www.google.com"));
        a.put(novo("link", "YouTube", "https://www.youtube.com"));
        a.put(novo("link", "Wikipédia", "https://pt.wikipedia.org"));
        return a;
    }

    private JSONObject novo(String tipo, String nome, String alvo) {
        JSONObject o = new JSONObject();
        try {
            o.put("tipo", tipo);
            o.put("nome", nome);
            o.put("alvo", alvo);
        } catch (JSONException ignored) {
        }
        return o;
    }

    // ---------- interface ----------

    private void atualizar() {
        grade.removeAllViews();
        PackageManager pm = getPackageManager();

        for (int i = 0; i < itens.length(); i++) {
            final JSONObject item = itens.optJSONObject(i);
            if (item == null) continue;
            final int posicao = i;
            final String tipo = item.optString("tipo");
            final String nome = item.optString("nome");
            final String alvo = item.optString("alvo");

            LinearLayout celula = new LinearLayout(this);
            celula.setOrientation(LinearLayout.VERTICAL);
            celula.setGravity(Gravity.CENTER_HORIZONTAL);
            celula.setPadding(dp(4), dp(12), dp(4), dp(12));

            View icone;
            if ("app".equals(tipo)) {
                ImageView img = new ImageView(this);
                try {
                    img.setImageDrawable(pm.getApplicationIcon(alvo));
                } catch (PackageManager.NameNotFoundException e) {
                    img.setImageDrawable(pm.getDefaultActivityIcon());
                }
                icone = img;
            } else {
                TextView letra = new TextView(this);
                letra.setText(nome.isEmpty() ? "?" : nome.substring(0, 1).toUpperCase());
                letra.setTextColor(Color.WHITE);
                letra.setTextSize(TypedValue.COMPLEX_UNIT_SP, 24);
                letra.setTypeface(Typeface.DEFAULT_BOLD);
                letra.setGravity(Gravity.CENTER);
                GradientDrawable fundo = new GradientDrawable();
                fundo.setShape(GradientDrawable.OVAL);
                fundo.setColor(CORES[Math.abs(nome.hashCode()) % CORES.length]);
                letra.setBackground(fundo);
                icone = letra;
            }
            celula.addView(icone, new LinearLayout.LayoutParams(dp(56), dp(56)));

            TextView rotulo = new TextView(this);
            rotulo.setText(nome);
            rotulo.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
            rotulo.setTextColor(0xFF111827);
            rotulo.setGravity(Gravity.CENTER);
            rotulo.setMaxLines(2);
            rotulo.setEllipsize(android.text.TextUtils.TruncateAt.END);
            LinearLayout.LayoutParams lpRotulo = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lpRotulo.topMargin = dp(6);
            celula.addView(rotulo, lpRotulo);

            celula.setOnClickListener(v -> abrir(tipo, alvo));
            celula.setOnLongClickListener(v -> {
                new AlertDialog.Builder(this)
                        .setTitle(nome)
                        .setMessage("Remover este atalho?")
                        .setPositiveButton("Remover", (d, w) -> {
                            itens.remove(posicao);
                            salvar();
                            atualizar();
                        })
                        .setNegativeButton("Cancelar", null)
                        .show();
                return true;
            });

            GridLayout.LayoutParams lp = new GridLayout.LayoutParams(
                    GridLayout.spec(GridLayout.UNDEFINED),
                    GridLayout.spec(GridLayout.UNDEFINED, 1f));
            lp.width = 0;
            grade.addView(celula, lp);
        }
    }

    private void abrir(String tipo, String alvo) {
        try {
            if ("app".equals(tipo)) {
                Intent it = getPackageManager().getLaunchIntentForPackage(alvo);
                if (it == null) {
                    Toast.makeText(this, "App não está instalado", Toast.LENGTH_SHORT).show();
                    return;
                }
                startActivity(it);
            } else {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(normalizarUrl(alvo))));
            }
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, "Não foi possível abrir", Toast.LENGTH_SHORT).show();
        }
    }

    private String normalizarUrl(String url) {
        String u = url.trim();
        if (!u.contains("://")) u = "https://" + u;
        return u;
    }

    // ---------- adicionar ----------

    private void escolherTipo() {
        new AlertDialog.Builder(this)
                .setTitle("Novo atalho")
                .setItems(new String[]{"Site / link", "App instalado"}, (d, which) -> {
                    if (which == 0) dialogoLink();
                    else dialogoApp();
                })
                .show();
    }

    private void dialogoLink() {
        LinearLayout caixa = new LinearLayout(this);
        caixa.setOrientation(LinearLayout.VERTICAL);
        caixa.setPadding(dp(20), dp(8), dp(20), 0);

        final EditText nome = new EditText(this);
        nome.setHint("Nome (ex: Notícias)");
        nome.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        caixa.addView(nome);

        final EditText url = new EditText(this);
        url.setHint("Endereço (ex: g1.globo.com)");
        url.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        caixa.addView(url);

        new AlertDialog.Builder(this)
                .setTitle("Site / link")
                .setView(caixa)
                .setPositiveButton("Salvar", (d, w) -> {
                    String n = nome.getText().toString().trim();
                    String u = url.getText().toString().trim();
                    if (u.isEmpty()) {
                        Toast.makeText(this, "Informe o endereço", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    if (n.isEmpty()) n = u.replaceFirst("^[a-zA-Z]+://", "").replaceFirst("^www\\.", "");
                    itens.put(novo("link", n, normalizarUrl(u)));
                    salvar();
                    atualizar();
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void dialogoApp() {
        PackageManager pm = getPackageManager();
        Intent principal = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> lista = pm.queryIntentActivities(principal, 0);

        final List<String[]> apps = new ArrayList<>(); // {nome, pacote}
        for (ResolveInfo ri : lista) {
            String pacote = ri.activityInfo.packageName;
            if (pacote.equals(getPackageName())) continue;
            apps.add(new String[]{String.valueOf(ri.loadLabel(pm)), pacote});
        }
        Collections.sort(apps, (a, b) -> a[0].compareToIgnoreCase(b[0]));

        String[] nomes = new String[apps.size()];
        for (int i = 0; i < nomes.length; i++) nomes[i] = apps.get(i)[0];

        new AlertDialog.Builder(this)
                .setTitle("Escolha um app")
                .setItems(nomes, (d, which) -> {
                    String[] escolhido = apps.get(which);
                    itens.put(novo("app", escolhido[0], escolhido[1]));
                    salvar();
                    atualizar();
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }
}
